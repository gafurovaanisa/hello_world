#include <iostream>

using namespace std;

/*
 * This is a simple Hello World program in C++.
 */
int main() {
    // Print Hello World to the terminal
    cout << "Hello World!" << endl;

    return 0;
}
